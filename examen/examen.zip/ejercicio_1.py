# -*- coding: utf-8 -*-
"""
Examen práctico 1
Autor: Chavez Islas Jair
Semestre: 2024-EJ
Curso: Minería de datos
Fecha: 2024-03-04
Descripción: Juego de los dados vs la computadora
"""

import random as rd

def iniciar_juego():

    #Se repetira hasta que haya un ganador
    while(sum(array_pl)<=30 or sum(array_pc) <=30):
        dec = ''
        #Se repite hasta que la decision sea correcta
        while(dec != 'j' and dec != 'q' ):
            dec = input('Entra j para jugar o q para salir del juego: ')
            if(dec.lower() == 'j'):
                tirar_dados(array_pc, array_pl)
                #Verifica si el jugador gano o perdio siendo 30 el limite d epuntos
                if(sum(array_pl) >=30):
                    mensaje_ganador(array_pl)
                if(sum(array_pc) >=30):
                    mensaje_perdedor(array_pl)
            if(dec.lower() == 'q'):
                print('************************\n* ¡¡Gracias por jugar! *\n************************')
                return 0
            if(dec.lower() != 'j' and dec.lower() != 'q'):
                print('¡Opción no válida!')
                iniciar_juego()
    
            
            
    
def tirar_dados(array_pc, array_pl):
    n1 = rd.randint(1, 6)
    if(n1 == 1):
        array_pc.clear()#Borra la lista si es que sale 1
    else:
        array_pc.append(n1)#Agrega los elementos a la lista si NO sale 1, para guardar la secuencia
    
    n2 = rd.randint(1, 6)
    
    if(n2 == 1):
        array_pl.clear()#Borra la lista si sale 1
    else:
        array_pl.append(n2)
    

    
    print(f'Numero para el usuario : {n2}')
    print(f'Numero para la computadora : {n1}')
    
    print(f'Total de puntos para el usuario: {sum(array_pl)}')
    print(f'Total de puntos para la maquina: {sum(array_pc)}')
    
    return array_pc, array_pl#Retorna los 2 arrays que recibe
    
    
def volver_a_jugar():
    
    dec = ''
    while(dec.lower() != 's' or dec.lower() != 'n'):
        dec = input('¿Quieres volver a jugar? s/n:')#Mensjae d eocnfirmacion para volve ra jugar
        
        if(dec.lower() == 's'):
            iniciar_juego()
        if(dec.lower() == 'n'):
            return 0
        if(dec.lower() != 's' and dec.lower() != 'n'):
            print('¡Opción no válida!')

def mensaje_perdedor(array_pl):#Mensjae a imprimir en caso de perder
    print('*********************************\n* :( Perdiste ¡Inténtalo mejor! *\n*********************************')
    print(f'secuencia perdedora: {array_pl}')
    volver_a_jugar()

def mensaje_ganador(array_pl):
    print('*********************************************\n* ¡¡Felicidades, has ganado la partida!! *\n*********************************************')
    print(f'secuencia perdedora: {array_pl}')
    volver_a_jugar()

#Inicia los arrays sin elementos, estos son los queguardaran los valores de los dados
array_pc = []
array_pl = []
#Inicia la funcion iniciar juego
iniciar_juego()