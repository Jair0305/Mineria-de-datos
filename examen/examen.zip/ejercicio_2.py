# -*- coding: utf-8 -*-
"""
Examen práctico 1
Autor: Chavez Islas Jair
Semestre: 2024-EJ
Curso: Minería de datos
Fecha: 2024-03-04
Descripción: 
"""
import random as rd
words = {'tormenta':'“Perturbación atmosférica viEolenta acompañada de aparato eléctrico y viento fuerte, lluvia, nieve o granizo.”'}
word = words['tormenta']



for i in range(0,3):    
    print(f'Adivina la siguiente palabra: \n ')